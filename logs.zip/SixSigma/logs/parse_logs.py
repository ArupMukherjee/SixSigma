import io
files = ['subject1a3.log', 'subject3b.log']


for file in files:
    results = {'current' : [], 'new' : []}
    f = io.open(file, encoding='utf-8')
    result = None
    method = None
    #read each lin of file
    for line in f:

        #check for start of a value        
        if 'SIXSIGMA:prompt' in line:
            parts = line.split('SIXSIGMA:')[1].split(',')
            method = 'current'
            if parts[1] == 'True': 
                method = 'new'
            parts[2] = parts[2][:-1]
            result = [parts[2], len(parts[2]), 0, 0, 0]
        
        if result is not None:
            #check for ignores and rejections of each digit
            for i in range(10):
                if '^^' + str(i) in line and 'IGNORING' in line:
                    result[2] += 1
                
                if '^^' + str(i) in line and 'REJECTED' in line:
                    result[3] += 1
            
            #check for end of a value entry
            if 'SIXSIGMA:result' in line:
                parts = line.split('SIXSIGMA:')[1].split(',')
                if parts[4] == 'False' or parts[5] == 'False':
                    result[4] += 1
                    
                results[method].append(result)
    
    
    #print out results for file
    total_result = ['total', 0, 0,0,0]
    indiv_cnt = [[0 for x in range(4)] for x in range(7)] 
    #indiv_cnt = [0,0,0,0,0,0,0][0,0,0,0]
    for r in results['current']:
        total_result[1] += r[1]
        total_result[2] += r[2]
        total_result[3] += r[3]
        total_result[4] += r[4]
        indiv_cnt[r[1]][0] += 1
        indiv_cnt[r[1]][1] += r[2]
        indiv_cnt[r[1]][2] += r[3]
        indiv_cnt[r[1]][3] += r[4]
        #print('current,', r)
    print(file, 'current',total_result)
    print('Individual Counts', indiv_cnt)

    total_result = ['total', 0, 0,0,0]
    indiv_cnt = [[0 for x in range(4)] for x in range(7)]
    #indiv_cnt = [0,0,0,0,0,0,0][0,0,0,0]
    #indiv_cnt = [1][4]
    for r in results['new']:
        total_result[1] += r[1]
        total_result[2] += r[2]
        total_result[3] += r[3]
        total_result[4] += r[4]
        indiv_cnt[r[1]][0] += 1
        indiv_cnt[r[1]][1] += r[2]
        indiv_cnt[r[1]][2] += r[3]
        indiv_cnt[r[1]][3] += r[4]
        
        #print('new,', r)
    print(file, 'new    ',total_result)
    print('Individual Counts', indiv_cnt)
                
            